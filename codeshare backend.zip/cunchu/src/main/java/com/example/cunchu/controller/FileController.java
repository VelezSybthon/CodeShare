package com.example.cunchu.controller;

import com.baomidou.mybatisplus.extension.api.R;
import com.example.cunchu.bean.FileVO;
import com.example.cunchu.service.FileService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

@Slf4j
@RestController
@Api(tags = "文件上传接口")
@RequestMapping("/file")
public class FileController {

    @Resource
    private FileService fileService;

    @ApiOperation("根据id查询单个")
    @GetMapping("/getById")
    public R getById(Integer id) {
        return R.ok(fileService.getVOById(id));
    }

    @ApiOperation("文件单个上传")
    @PostMapping("/uploadByOne")
    public R uploadByOne(@RequestParam("file") MultipartFile file) throws IOException {
        try (InputStream is = file.getInputStream();
             ByteArrayOutputStream os = new ByteArrayOutputStream()) {
            IOUtils.copy(is, os);
            byte[] bytes = os.toByteArray();
            FileVO vo = fileService.storeFile(bytes, file.getOriginalFilename());
            return R.ok(vo);
        } catch (IOException e) {
            log.error("文件上传发生异常 -> {}", e.getMessage());
            return R.failed("文件上传失败");
        }
    }

}
