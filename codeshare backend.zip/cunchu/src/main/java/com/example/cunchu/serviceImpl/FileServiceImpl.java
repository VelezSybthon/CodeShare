package com.example.cunchu.serviceImpl;


import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.cunchu.bean.FileVO;
import com.example.cunchu.service.FileService;


import com.fasterxml.jackson.databind.util.BeanUtil;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Map;
import java.util.function.Function;

@Service
public class FileServiceImpl implements FileService {

    @Value("${file.path}")
    private String FILE_PATH;
    @Value("${access.base-url.file}")
    private String ACCESS_BASE_URL;

    private DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMdd");


    @Override
    public FileVO getVOById(Integer id) {
        return null;
    }

    @Override
    public FileVO storeFile(byte[] content, String originFileName) {
        // 获取文件后缀 生成目录路径
        // 配置文件里的file.path + yyyyMMdd 格式组成文件夹路径
        String folder = LocalDateTime.now().format(dateTimeFormatter);
        String suffix = originFileName.substring(originFileName.lastIndexOf(".")),
                filePath = FILE_PATH + folder + File.separatorChar;
        // 保存文件并返回文件名
        String fileName = this.storeFile(content, filePath, suffix);


    }

    @Override
    public void storeFileWithFileName(byte[] content, String path, String fileName) {
        // 目录不存在则创建
        java.io.File file = new java.io.File(path);
        if (!file.exists()) {
            file.mkdirs();
        }
        try (FileOutputStream os = new FileOutputStream(path + fileName);
             ByteArrayInputStream is = new ByteArrayInputStream(content)) {
            IOUtils.copy(is, os);
        } catch (IOException e) {

        }
    }

    private String storeFile(byte[] content, String path, String suffix) {
        String fileName = generateFileName(suffix);
        storeFileWithFileName(content, path, fileName);
        return fileName;
    }

    private String generateFileName(String suffix) {
        return generateFileName() + suffix;
    }

    private String genAccessUrl(String folder, String name) {
        return ACCESS_BASE_URL + folder + "/" + name;
    }



    @Override
    public boolean saveBatch(Collection<File> entityList, int batchSize) {
        return false;
    }

    @Override
    public boolean saveOrUpdateBatch(Collection<File> entityList, int batchSize) {
        return false;
    }

    @Override
    public boolean updateBatchById(Collection<File> entityList, int batchSize) {
        return false;
    }

    @Override
    public boolean saveOrUpdate(File entity) {
        return false;
    }

    @Override
    public File getOne(Wrapper<File> queryWrapper, boolean throwEx) {
        return null;
    }

    @Override
    public Map<String, Object> getMap(Wrapper<File> queryWrapper) {
        return null;
    }

    @Override
    public <V> V getObj(Wrapper<File> queryWrapper, Function<? super Object, V> mapper) {
        return null;
    }

    @Override
    public BaseMapper<File> getBaseMapper() {
        return null;
    }
}
