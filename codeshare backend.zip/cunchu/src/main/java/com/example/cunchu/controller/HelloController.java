package com.example.cunchu.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

    @Api(tags = "控制器--Hello")
    @RequestMapping("/hello")
    @RestController
    public class HelloController {

        @PostMapping("/insert")
        @ApiOperation("新增方法--insert")
        public String insert() {
            return "insert";
        }

        @PutMapping("/update")
        @ApiOperation("修改方法--update")
        public String update() {
            return "update";
        }

        @DeleteMapping("/delete")
        @ApiOperation("删除方法--delete")
        public String delete() {
            return "delete";
        }

        @GetMapping("/getAll")
        @ApiOperation("查询方法--getAll")
        public String getAll() {
            return "getAll";
        }
    }



