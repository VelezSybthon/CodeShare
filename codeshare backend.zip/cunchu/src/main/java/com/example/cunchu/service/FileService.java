package com.example.cunchu.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.cunchu.bean.FileVO;

import java.io.File;

public interface FileService extends IService<File> {

    /**
     * 根据ID获取视图对象
     * @param id
     * @return
     */
    FileVO getVOById(Integer id);

    /**
     * 文件上传
     * @param content
     * @param originFileName
     * @return
     */
    FileVO storeFile(byte[] content, String originFileName);

    /**
     * 存储文件到本地
     * @param content
     * @param path
     * @param fileName
     */
    void storeFileWithFileName(byte[] content, String path, String fileName);
}
